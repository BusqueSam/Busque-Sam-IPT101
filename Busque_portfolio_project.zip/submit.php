<?php
require_once __DIR__ . '/config.php';

// Start session is done in config
$errors = [];
$old = [];

$name = isset($_POST['name']) ? trim($_POST['name']) : '';
$subject = isset($_POST['subject']) ? trim($_POST['subject']) : '';
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$message = isset($_POST['message']) ? trim($_POST['message']) : '';

$old['name']=$name;
$old['subject']=$subject;
$old['email']=$email;
$old['message']=$message;

// Server-side validation
if ($name === '') $errors[] = 'Name is required.';
if ($subject === '') $errors[] = 'Subject is required.';
if ($email === '') $errors[] = 'Email is required.';
if ($message === '') $errors[] = 'Message is required.';
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid email format.';
if (mb_strlen($message) > 150) $errors[] = 'Message cannot exceed 150 characters.';

if (!empty($errors)) {
    // Persist old input and errors
    $_SESSION['errors'] = $errors;
    $_SESSION['old'] = $old;
    // Redirect back to the form
    header('Location: contact/index.php');
    exit;
}

// Insert into database
try {
    $stmt = $pdo->prepare('INSERT INTO email (name, subject, recipient_email, messages, sent_at, created_at) VALUES (?, ?, ?, ?, NOW(), NOW())');
    $stmt->execute([$name, $subject, $email, $message]);
    // Success alert and redirect back to form (we'll use JS alert via query param)
    $_SESSION['success'] = true;
    header('Location: contact/index.php?success=1');
    exit;
} catch (Exception $e) {
    // Failure
    $_SESSION['errors'] = ['Error! Please try again.'];
    $_SESSION['old'] = $old;
    header('Location: contact/index.php');
    exit;
}
