<?php
// Project root index - redirect to contact form
header('Location: contact/index.php');
exit;
