<?php
require_once 'config.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: dashboard.php');
    exit;
}
$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
if ($id <= 0) {
    header('Location: dashboard.php');
    exit;
}
$stmt = $pdo->prepare('DELETE FROM email WHERE id = ?');
$stmt->execute([$id]);
header('Location: dashboard.php');
exit;
