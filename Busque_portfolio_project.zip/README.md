# Semifinal Project - Contact Form + Admin Dashboard

## Structure
- contact/index.php (Contact form)
- submit.php (Form handler)
- config.php (Database connection)
- dashboard.php (Admin dashboard)
- view.php (View single message)
- delete.php (Delete message)
- create_db.sql (SQL to create database and table)
- assets/style.css (basic styles)
- assets/script.js (client-side validation)

## Notes
- Database name: `db_portfolio`
- Table: `email` (columns: id, name, subject, recipient_email, messages, sent_at, created_at)
- Use PHP (>=7) and MySQL / MariaDB.
- Place the project in a PHP-enabled server (e.g., XAMPP) and import `create_db.sql`.
- Default DB credentials are in `config.php` — change as needed.

