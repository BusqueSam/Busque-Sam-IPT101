<?php
require_once 'config.php';

// Fetch all messages ordered by newest first
$stmt = $pdo->query('SELECT * FROM email ORDER BY id DESC');
$messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Admin Dashboard</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="admin">
  <aside class="sidebar">
    <h2>Menu</h2>
    <ul>
      <li><a href="dashboard.php">Email</a></li>
    </ul>
  </aside>
  <main class="main">
    <h1>Messages</h1>
    <table border="1" cellpadding="8" cellspacing="0">
      <thead>
        <tr>
          <th>Name</th>
          <th>Subject</th>
          <th>Message</th>
          <th>Date Submitted</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($messages as $m): ?>
        <tr>
          <td><?=htmlspecialchars($m['name'])?></td>
          <td><?=htmlspecialchars($m['subject'])?></td>
          <td><?=htmlspecialchars(mb_strimwidth($m['messages'],0,60,'...'))?></td>
          <td><?=htmlspecialchars($m['created_at'])?></td>
          <td>
            <a href="view.php?id=<?=urlencode($m['id'])?>">View</a> |
            <form method="post" action="delete.php" style="display:inline" onsubmit="return confirmDelete();">
              <input type="hidden" name="id" value="<?=htmlspecialchars($m['id'])?>">
              <button type="submit">Delete</button>
            </form>
          </td>
        </tr>
        <?php endforeach;?>
      </tbody>
    </table>
  </main>
</div>

<script>
function confirmDelete(){
  return confirm('Are you sure you want to delete this message?');
}
</script>
</body>
</html>
