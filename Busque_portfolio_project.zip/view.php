<?php
require_once 'config.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare('SELECT * FROM email WHERE id = ?');
$stmt->execute([$id]);
$msg = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$msg) {
    echo 'Message not found.';
    exit;
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>View Message</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="container">
  <h2>Message Details</h2>
  <p><strong>Name:</strong> <?=htmlspecialchars($msg['name'])?></p>
  <p><strong>Subject:</strong> <?=htmlspecialchars($msg['subject'])?></p>
  <p><strong>Email:</strong> <?=htmlspecialchars($msg['recipient_email'])?></p>
  <p><strong>Message:</strong><br><?=nl2br(htmlspecialchars($msg['messages']))?></p>
  <p><strong>Submitted at:</strong> <?=htmlspecialchars($msg['created_at'])?></p>
  <p><a href="dashboard.php">Back to dashboard</a></p>
</div>
</body>
</html>
