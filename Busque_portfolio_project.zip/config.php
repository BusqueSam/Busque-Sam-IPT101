<?php
// Database configuration - change these to match your environment
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'db_portfolio';

try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    // For production, avoid exposing details
    die('Database connection failed: ' . $e->getMessage());
}
session_start();
?>
