<?php
require_once __DIR__ . '/../../config.php';
session_start();
$old = isset($_SESSION['old']) ? $_SESSION['old'] : ['name'=>'','subject'=>'','email'=>'','message'=>''];
$errors = isset($_SESSION['errors']) ? $_SESSION['errors'] : [];
unset($_SESSION['errors'], $_SESSION['old']);
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Contact Form</title>
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="container">
  <h1>Contact Us</h1>
  <?php if (!empty($errors)): ?>
    <div class="errors">
      <ul>
        <?php foreach($errors as $e): ?>
          <li><?=htmlspecialchars($e)?></li>
        <?php endforeach;?>
      </ul>
    </div>
  <?php endif;?>
  <form id="contactForm" method="post" action="../submit.php" novalidate>
    <label>Name (required)
      <input type="text" name="name" required value="<?=htmlspecialchars($old['name'])?>">
    </label>
    <label>Subject (required)
      <input type="text" name="subject" required value="<?=htmlspecialchars($old['subject'])?>">
    </label>
    <label>Email (required)
      <input type="email" name="email" required value="<?=htmlspecialchars($old['email'])?>">
    </label>
    <label>Message (max 150 chars)
      <textarea name="message" maxlength="150" required><?=htmlspecialchars($old['message'])?></textarea>
    </label>
    <button type="submit">Send Message</button>
  </form>
</div>

<script src="../assets/script.js"></script>
</body>
</html>
