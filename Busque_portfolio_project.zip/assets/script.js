// Client-side validation and success/failure alerts
document.addEventListener('DOMContentLoaded', function() {
  const form = document.getElementById('contactForm');
  form.addEventListener('submit', function(e) {
    const email = form.email.value.trim();
    const message = form.message.value.trim();
    let clientErrors = [];
    if (!email) clientErrors.push('Email is required.');
    else {
      // basic email regex
      const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!re.test(email)) clientErrors.push('Invalid email format.');
    }
    if (!form.name.value.trim()) clientErrors.push('Name is required.');
    if (!form.subject.value.trim()) clientErrors.push('Subject is required.');
    if (!message) clientErrors.push('Message is required.');
    if (message.length > 150) clientErrors.push('Message cannot exceed 150 characters.');

    if (clientErrors.length) {
      e.preventDefault();
      alert('Error! Please try again.\n' + clientErrors.join('\n'));
    }
  });

  // show success alert if redirected with success param
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.get('success') === '1') {
    alert('Your message has been successfully sent!');
    // remove the param from the URL without reloading
    if (history.replaceState) {
      const url = new URL(window.location);
      url.searchParams.delete('success');
      history.replaceState(null, '', url.pathname + url.search);
    }
  }
});
